<!DOCTYPE html>
<html>
    <head>
        <title>Paypal Order Complete - Demo</title>
        <meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
        <link rel="stylesheet" href="css/style.css" />
    </head>
    <body>
        <div class="main-container">
            <div class="section">
                <h3>You order has been confirmed.</h3>
            </div>
        </div>
    </body>
</html>
