<?php
session_start();
include("constants.php");

//=== Import the PayPal SDK client that was created in `Set up Server-Side SDK`.
require __DIR__ . '/vendor/autoload.php';

use PayPalCheckoutSdk\Core\PayPalHttpClient;
use PayPalCheckoutSdk\Core\SandboxEnvironment;
use PayPalCheckoutSdk\Orders\OrdersCreateRequest;
use PayPalCheckoutSdk\Orders\OrdersCaptureRequest;

class paypalRequest
{
    //=== Setup Paypal Environment.
    public static function environment()
    {
        return new SandboxEnvironment(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET);
    }

    //=== Setup Paypal Client.
    public static function client()
    {
        return new PayPalHttpClient(self::environment());
    }

    //=== Create papal order
    public static function createOrder( $debug = false )
    {
        //=== Create New Order Request
        $request = new OrdersCreateRequest();
        $request->prefer("return=representation");

        //=== Create Request Body
        $request->body = self::buildRequestBody();

        //=== Call PayPal to set up a transaction
        $client = self::client();
        $response = $client->execute($request);

        //=== Return a response to the client.
        return $response;
    }

    public static function captureOrder($order_id)
    {
        $request = new OrdersCaptureRequest($order_id);

        //=== Call PayPal to get the transaction details
        $client = self::client();
        $response = $client->execute($request);

        return $response;
    }

    private static function buildRequestBody()
    {
        //=== Graceful die if cart is not set in session
        if( !isset($_SESSION["cart"]) ){
            die(json_encode(["success" => 0, "message" => "No items found in cart"]));
        }
        //=== Assign cart from session to a variable
        $cart = $_SESSION["cart"];
        //=== Set currency code used in transaction
        $currency_code = "USD";

        $request_body = $application_context = $purchase_units = $pu_amount = [];

        //=== Prepare context of our request
        $application_context["locale"] = "en-US";
        $application_context["user_action"] = "PAY_NOW";

        //=== Prepare amount & break down of amount for order
        $pu_amount["currency_code"] = $currency_code;
        $pu_amount["value"] = floatval($cart["cart_total"]);

        //=== Items total break down without tax
        $pu_amount["breakdown"]["item_total"]["currency_code"] = $currency_code;
        $pu_amount["breakdown"]["item_total"]["value"] = number_format($cart["items_total"], 2);

        //=== Total tax of all products
        $pu_amount["breakdown"]["tax_total"]["currency_code"] = $currency_code;
        $pu_amount["breakdown"]["tax_total"]["value"] = number_format($cart["tax_total"], 2);

        $purchase_units["amount"] = $pu_amount;

        $items = [];

        //=== Loop through all products in session and prepare items array for order request
        if( !empty($cart["products"]) ){
            foreach($cart["products"] as $product){
                $item["name"]= $product["product_title"];
                $item["quantity"]= $product["product_quantity"];
                $item["category"]= "DIGITAL_GOODS";

                //=== Unit amount of product (widthout tax)
                $item["unit_amount"]["currency_code"] = $currency_code;
                $item["unit_amount"]["value"]= number_format($product["product_price"], 2);

                $items[] = $item;
            }
        }

        $purchase_units["items"] = $items;

        //=== Finally create request body array assigning context & purchase units created above
        $request_body["intent"] = "CAPTURE";
        $request_body["application_context"] = $application_context;
        $request_body["purchase_units"][] = $purchase_units;

        return $request_body;
    }
}

if ( !count( debug_backtrace() ) )
{
    //=== Capture the input received from fetch() request
    $json_data = file_get_contents("php://input");
    $post = json_decode($json_data);

    //=== Check if request is to create an order
    if($post->action == "create-order")
    {
        $order = paypalRequest::createOrder();
        echo json_encode($order->result, JSON_PRETTY_PRINT);
    }
    //=== Check if request is to save an order
    elseif($post->action == "save-order")
    {
        //=== Save order either by retrieving order from paypal OR the order we still have in session
        $order = paypalRequest::captureOrder($post->id);

        /*
        Prepare order query data & save order into database here
        */
        //===  unset cart session
        unset($_SESSION["cart"]);

        echo json_encode(["success" => 1], JSON_PRETTY_PRINT);
    }
}
?>