window.addEventListener("load", function(){
    //=== Render paypal Buttons
    paypal.Buttons({
        style:{
            layout: "horizontal"
        },
        //=== Call your server to create an order
        createOrder: function(data, actions) {
            return fetch("paypal-request.php", {
                mode: "no-cors",
                method: "POST",
                headers: {
                    "content-type": "application/json"
                },
                body: JSON.stringify({
                    action: "create-order",
                })
            }).then(function(res) {
                return res.json();
            }).then(function(data) {
                if( !data.success && data.message ){
                    console.error(data.message);
                }
                return data.id;
            });
        },
        //=== Call your server to save the transaction
        onApprove: function(data, actions){
            return fetch("paypal-request.php", {
                mode: "no-cors",
                method: "POST",
                headers: {
                    "content-type": "application/json"
                },
                body: JSON.stringify({
                    action: "save-order",
                    id: data.orderID
                })
            }).then(function(res) {
                return res.json();
            }).then(function(data){
                //=== Redirect to thank you/success page after saving transaction
                if(data.success){
                    window.location.assign("payment-success.php");
                }
            });
        }
    }).render("#paypal-buttons");
});